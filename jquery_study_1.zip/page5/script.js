$(function() {
  // Use the show() method to show the element with the id "title"
  $('#title').show();
  
  // Use the fadeIn() method to show the element with the id "image"
  $('#image').fadeIn();
  
});